function handler () {
    topic=$(aws sns list-topics | jq -r ".Topics[ ] | .TopicArn" | grep BillingEmailAlertTopic )
    aws sns publish --topic-arn $topic --message “You reached the warning level of your AWS sandbox budget. We’ll stop your was resources to reduce unwanted billing.”

    aws cloudformation create-stack --stack-name cfn-freeze-stack  \
    --capabilities "CAPABILITY_IAM" "CAPABILITY_NAMED_IAM" \
    --template-url https://cf-template-datascientest-sandboxes.s3.amazonaws.com/aws-freeze-service.yaml  \
    --parameters ParameterKey=NotificationEmailAddress,ParameterValue='ahmedhosni.contact@gmail.com' ParameterKey=WhenToExecute,ParameterValue='cron(0 0 * * ? *)' ParameterKey=RetentionInDays,ParameterValue=14 ParameterKey=AWSFreezeProfileName,ParameterValue=freeze
}